import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
from PIL import Image, ImageTk
import difflib  

icon_path = "/Users/fabiendallmann/Desktop/Computational_Morphology/ExtrahierenundVergleichen/Mainpic.webp"

def center_window(window, width, height):
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()

    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)

    window.geometry(f"{width}x{height}+{x}+{y}")

def start_program():
    splash_screen.destroy()
    main_program()

def update_progress(current_progress=0):
    total_duration = 3000  
    steps = 100
    step_duration = total_duration // steps

    if current_progress <= 100:
        progress_var.set(current_progress)
        progress_label.config(text=f"{current_progress}%")  
        splash_screen.after(step_duration, update_progress, current_progress + 1)
    else:
        start_program()

def select_file_for_extraction():
    file_path = filedialog.askopenfilename()
    if file_path:
        entry_extraction.delete(0, tk.END)
        entry_extraction.insert(0, file_path)

def extract_unique_lines():
    file_path = entry_extraction.get()
    if not os.path.isfile(file_path):
        messagebox.showerror("Fehler", "Die angegebene Datei existiert nicht!")
        return
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        unique_lines = set(lines)
        directory = os.path.dirname(file_path)
        base_name = os.path.basename(file_path).rsplit('.', 1)[0]
        new_file_path = os.path.join(directory, f"{base_name}_extracted_output.txt")
        with open(new_file_path, 'w', encoding='utf-8') as file:
            file.writelines(sorted(unique_lines))
        messagebox.showinfo("Erfolg", f"Eindeutige Zeilen wurden in '{new_file_path}' gespeichert.")
    except Exception as e:
        messagebox.showerror("Fehler", f"Ein Fehler ist aufgetreten: {e}")

def select_file_1():
    file_path = filedialog.askopenfilename()
    if file_path:
        entry_file_1.delete(0, tk.END)
        entry_file_1.insert(0, file_path)

def select_file_2():
    file_path = filedialog.askopenfilename()
    if file_path:
        entry_file_2.delete(0, tk.END)
        entry_file_2.insert(0, file_path)


def find_best_match(word, reference_words, similarity_threshold=0.6):
    best_match = None
    highest_similarity = similarity_threshold
    
    for ref_word in reference_words:
        similarity = difflib.SequenceMatcher(None, word, ref_word).ratio()
        
        if similarity == 1.0:
            best_match = ref_word
        
        if similarity > highest_similarity:
            best_match = ref_word
            highest_similarity = similarity
            
    return best_match


def compare_files():
    file_path_1 = entry_file_1.get()
    file_path_2 = entry_file_2.get()

    if not (os.path.isfile(file_path_1) and os.path.isfile(file_path_2)):
        messagebox.showerror("Fehler", "Eine oder beide Dateien existieren nicht!")
        return

    try:
        with open(file_path_1, 'r', encoding='utf-8') as file1:
            words_file_1 = file1.read().split()

        with open(file_path_2, 'r', encoding='utf-8') as file2:
            words_file_2 = file2.read().split()

        word_matches = {word: (None, "✘", "red") for word in words_file_2}

        for ref_word in words_file_2:
            best_match = find_best_match(ref_word, words_file_1)
            if best_match:
                if best_match == ref_word:
                    word_matches[ref_word] = (best_match, "✔", "green")
                else:
                    word_matches[ref_word] = (best_match, "⚠", "orange")
                words_file_1.remove(best_match)

        result_window = tk.Toplevel(root)
        result_window.title("Vergleich der Dateien")

        canvas = tk.Canvas(result_window)
        scroll_y = tk.Scrollbar(result_window, orient="vertical", command=canvas.yview)
        frame = tk.Frame(canvas)

        tk.Label(frame, text="Output (Datei 1)", font=("Arial", 12, "bold")).grid(row=0, column=0, padx=10, pady=5, sticky="w")
        tk.Label(frame, text="Expected (Datei 2)", font=("Arial", 12, "bold")).grid(row=0, column=1, padx=10, pady=5, sticky="w")
        tk.Label(frame, text="Vergleich", font=("Arial", 12, "bold")).grid(row=0, column=2, padx=10, pady=5, sticky="w")

        row_idx = 1
        for ref_word, (matched_word, symbol, color) in word_matches.items():
            tk.Label(frame, text=matched_word if matched_word else "", width=30, anchor="w").grid(row=row_idx, column=0, padx=10, pady=2)
            tk.Label(frame, text=ref_word, width=30, anchor="w").grid(row=row_idx, column=1, padx=10, pady=2)
            tk.Label(frame, text=symbol, fg=color).grid(row=row_idx, column=2, padx=10, pady=2)
            row_idx += 1

        canvas.create_window(0, 0, anchor="nw", window=frame)
        canvas.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"), yscrollcommand=scroll_y.set)

        canvas.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")

        result_window.update_idletasks()  
        result_window.geometry(f"{frame.winfo_reqwidth() + 20}x{min(600, frame.winfo_reqheight() + 20)}")

    except Exception as e:
        messagebox.showerror("Fehler", f"Ein Fehler ist aufgetreten: {e}")

def main_program():
    global root, entry_extraction, entry_file_1, entry_file_2

    root = tk.Tk()
    root.title("Extrahieren & Vergleichen")

    img_icon = ImageTk.PhotoImage(Image.open(icon_path))
    root.iconphoto(False, img_icon)

    center_window(root, 600, 400)
    label_extraction = tk.Label(root, text="Datei zum Extrahieren:")
    label_extraction.grid(row=0, column=0, padx=10, pady=10)

    entry_extraction = tk.Entry(root, width=50)
    entry_extraction.grid(row=0, column=1, padx=10, pady=10)

    button_select_extraction = tk.Button(root, text="Datei auswählen", command=select_file_for_extraction)
    button_select_extraction.grid(row=0, column=2, padx=10, pady=10)

    button_extract = tk.Button(root, text="Extrahieren", command=extract_unique_lines)
    button_extract.grid(row=0, column=3, padx=10, pady=10)

    label_file_1 = tk.Label(root, text="Output Datei 1:")
    label_file_1.grid(row=1, column=0, padx=10, pady=10)

    entry_file_1 = tk.Entry(root, width=50)
    entry_file_1.grid(row=1, column=1, padx=10, pady=10)

    button_select_1 = tk.Button(root, text="Datei auswählen", command=select_file_1)
    button_select_1.grid(row=1, column=2, padx=10, pady=10)

    label_file_2 = tk.Label(root, text="Expected Datei 2:")
    label_file_2.grid(row=2, column=0, padx=10, pady=10)

    entry_file_2 = tk.Entry(root, width=50)
    entry_file_2.grid(row=2, column=1, padx=10, pady=10)

    button_select_2 = tk.Button(root, text="Datei auswählen", command=select_file_2)
    button_select_2.grid(row=2, column=2, padx=10, pady=10)

    button_compare = tk.Button(root, text="Vergleichen", command=compare_files)
    button_compare.grid(row=2, column=3, padx=10, pady=20)

    root.mainloop()

splash_screen = tk.Tk()
splash_screen.title("Lade Extrahieren & Vergleichen")

img_icon = ImageTk.PhotoImage(Image.open(icon_path))
splash_screen.iconphoto(False, img_icon)

image = Image.open(icon_path)
image = image.resize((200, 200), Image.ANTIALIAS) 
img_icon_small = ImageTk.PhotoImage(image)
img_label = tk.Label(splash_screen, image=img_icon_small)
img_label.pack(pady=10)

progress_var = tk.IntVar()
progress_bar = ttk.Progressbar(splash_screen, orient="horizontal", length=200, mode="determinate", variable=progress_var)
progress_bar.pack(pady=10)

progress_label = tk.Label(splash_screen, text="0%")
progress_label.pack()

start_label = tk.Label(splash_screen, text="Starte...")
start_label.pack(pady=10)

center_window(splash_screen, 350, 400)

splash_screen.after(100, update_progress)

splash_screen.mainloop()
