import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
from PIL import Image, ImageTk

# Pfad zur Bilddatei auf deinem Computer (dies anpassen)
#icon_path = "/Users/fabiendallmann/Desktop/Computational_Morphology/Neuer Ordner/Data/Mainpic.webp"  # Passe diesen Pfad an den Speicherort des Bildes an


def resource_path(relative_path):
    """ Holt den absoluten Pfad zu einer Datei, egal ob sie aus einer EXE oder als Skript ausgeführt wird. """
    try:
        # PyInstaller erstellt ein temporäres Verzeichnis und speichert dort die Datei
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Der Pfad zur Bilddatei wird jetzt relativ festgelegt
icon_path = resource_path("icon_image.webp")


def start_program():
    """Schließt das Ladefenster und startet das eigentliche Programm."""
    splash_screen.destroy()
    main_program()

def update_progress(current_progress=0):
    """Aktualisiert den Ladebalken und zeigt den Fortschritt in Prozent."""
    # Gesamtdauer des Ladevorgangs in Millisekunden
    total_duration = 10000  # 10 Sekunden
    # Anzahl der Schritte (z.B. 100 für 100 %)
    steps = 100
    # Zeit pro Schritt (total_duration geteilt durch die Anzahl der Schritte)
    step_duration = total_duration // steps

    if current_progress <= 100:
        progress_var.set(current_progress)
        progress_label.config(text=f"{current_progress}%")  # Prozentanzeige aktualisieren
        splash_screen.after(step_duration, update_progress, current_progress + 1)  # Nächster Schritt in step_duration ms
    else:
        start_program()

def select_file_for_extraction():
    """Öffnet den Dateiauswahldialog für das Extrahieren."""
    file_path = filedialog.askopenfilename()
    if file_path:
        entry_extraction.delete(0, tk.END)
        entry_extraction.insert(0, file_path)

def extract_unique_lines():
    """Extrahiert eindeutige Zeilen aus der Datei und speichert sie mit '_extracted_output'."""
    file_path = entry_extraction.get()
    if not os.path.isfile(file_path):
        messagebox.showerror("Fehler", "Die angegebene Datei existiert nicht!")
        return
    try:
        # Datei mit eindeutigen Zeilen extrahieren
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        unique_lines = set(lines)
        # Pfad für die neue Datei generieren
        directory = os.path.dirname(file_path)
        base_name = os.path.basename(file_path).rsplit('.', 1)[0]  # Name der Datei ohne Erweiterung
        new_file_path = os.path.join(directory, f"{base_name}_extracted_output.txt")
        # Eindeutige Zeilen in die neue Datei schreiben
        with open(new_file_path, 'w', encoding='utf-8') as file:
            file.writelines(sorted(unique_lines))
        messagebox.showinfo("Erfolg", f"Eindeutige Zeilen wurden in '{new_file_path}' gespeichert.")
    except Exception as e:
        messagebox.showerror("Fehler", f"Ein Fehler ist aufgetreten: {e}")

def select_file_1():
    """Öffnet den Dateiauswahldialog für die erste Datei im Vergleich."""
    file_path = filedialog.askopenfilename()
    if file_path:
        entry_file_1.delete(0, tk.END)
        entry_file_1.insert(0, file_path)

def select_file_2():
    """Öffnet den Dateiauswahldialog für die zweite Datei im Vergleich."""
    file_path = filedialog.askopenfilename()
    if file_path:
        entry_file_2.delete(0, tk.END)
        entry_file_2.insert(0, file_path)

def compare_files():
    """Vergleicht die Zeilen der beiden Dateien und zeigt die Ergebnisse in einem neuen Fenster an."""
    file_path_1 = entry_file_1.get()
    file_path_2 = entry_file_2.get()

    if not (os.path.isfile(file_path_1) and os.path.isfile(file_path_2)):
        messagebox.showerror("Fehler", "Eine oder beide Dateien existieren nicht!")
        return

    try:
        # Dateien einlesen
        with open(file_path_1, 'r', encoding='utf-8') as file1:
            lines_file_1 = file1.readlines()

        with open(file_path_2, 'r', encoding='utf-8') as file2:
            lines_file_2 = file2.readlines()

        # Neues Fenster für die Ausgabe erstellen
        result_window = tk.Toplevel(root)
        result_window.title("Vergleich der Dateien")

        # Scrollbars hinzufügen
        canvas = tk.Canvas(result_window)
        scroll_y = tk.Scrollbar(result_window, orient="vertical", command=canvas.yview)
        frame = tk.Frame(canvas)

        # Vergleichsergebnisse anzeigen
        max_len = max(len(lines_file_1), len(lines_file_2))
        for i in range(max_len):
            line1 = lines_file_1[i].strip() if i < len(lines_file_1) else ""
            line2 = lines_file_2[i].strip() if i < len(lines_file_2) else ""

            # Zeilennummerierung
            label_number = tk.Label(frame, text=f"{i + 1}", width=5, anchor="w")
            label_line1 = tk.Label(frame, text=line1, anchor="w", width=50)
            label_line2 = tk.Label(frame, text=line2, anchor="w", width=50)

            # Häkchen oder Kreuz je nach Vergleich
            if line1 == line2:
                status = tk.Label(frame, text="✔", fg="green")
            else:
                status = tk.Label(frame, text="✘", fg="red")

            # Positionieren der Labels
            label_number.grid(row=i*2, column=0, padx=5, pady=2, sticky="w")
            label_line1.grid(row=i*2, column=1, padx=5, pady=2, sticky="w")
            label_line2.grid(row=i*2, column=2, padx=5, pady=2, sticky="w")
            status.grid(row=i*2, column=3, padx=5, pady=2, sticky="w")

            # Trennlinie unter jeder Zeile
            separator = ttk.Separator(frame, orient="horizontal")
            separator.grid(row=i*2 + 1, column=0, columnspan=4, sticky="ew", padx=5, pady=2)

        # Canvas und Scrollbar konfigurieren
        canvas.create_window(0, 0, anchor="nw", window=frame)
        canvas.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"), yscrollcommand=scroll_y.set)

        # Layout im neuen Fenster
        canvas.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")

        # Größe des Fensters automatisch anpassen
        result_window.update_idletasks()  # Aktualisiert den Inhalt vor dem Festlegen der Größe
        result_window.geometry(f"{frame.winfo_reqwidth() + 20}x{min(600, frame.winfo_reqheight() + 20)}")

    except Exception as e:
        messagebox.showerror("Fehler", f"Ein Fehler ist aufgetreten: {e}")

def main_program():
    """Hauptfenster für das Extrahieren und Vergleichen von Dateien."""
    global root, entry_extraction, entry_file_1, entry_file_2

    # Hauptfenster erstellen
    root = tk.Tk()
    root.title("Extrahieren & Vergleichen")

    # Setze das Icon für das Fenster
    img_icon = ImageTk.PhotoImage(Image.open(icon_path))
    root.iconphoto(False, img_icon)

    # --- Extrahieren-Teil ---

    # Label und Eingabefeld für die zu extrahierende Datei
    label_extraction = tk.Label(root, text="Datei zum Extrahieren:")
    label_extraction.grid(row=0, column=0, padx=10, pady=10)

    entry_extraction = tk.Entry(root, width=50)
    entry_extraction.grid(row=0, column=1, padx=10, pady=10)

    button_select_extraction = tk.Button(root, text="Datei auswählen", command=select_file_for_extraction)
    button_select_extraction.grid(row=0, column=2, padx=10, pady=10)

    # Button, um die Extraktion durchzuführen
    button_extract = tk.Button(root, text="Extrahieren", command=extract_unique_lines)
    button_extract.grid(row=0, column=3, padx=10, pady=10)

    # --- Vergleich-Teil ---

    # Eingabefelder und Buttons für die erste Datei
    label_file_1 = tk.Label(root, text="Datei 1:")
    label_file_1.grid(row=1, column=0, padx=10, pady=10)

    entry_file_1 = tk.Entry(root, width=50)
    entry_file_1.grid(row=1, column=1, padx=10, pady=10)

    button_select_1 = tk.Button(root, text="Datei auswählen", command=select_file_1)
    button_select_1.grid(row=1, column=2, padx=10, pady=10)

    # Eingabefelder und Buttons für die zweite Datei
    label_file_2 = tk.Label(root, text="Datei 2:")
    label_file_2.grid(row=2, column=0, padx=10, pady=10)

    entry_file_2 = tk.Entry(root, width=50)
    entry_file_2.grid(row=2, column=1, padx=10, pady=10)

    button_select_2 = tk.Button(root, text="Datei auswählen", command=select_file_2)
    button_select_2.grid(row=2, column=2, padx=10, pady=10)

    # Button, um die Dateien zu vergleichen
    button_compare = tk.Button(root, text="Vergleichen", command=compare_files)
    button_compare.grid(row=2, column=3, padx=10, pady=20)

    root.mainloop()

# Ladefenster erstellen
splash_screen = tk.Tk()
splash_screen.title("Lade Extrahieren & Vergleichen")

# Setze das Icon für das Ladefenster
img_icon = ImageTk.PhotoImage(Image.open(icon_path))
splash_screen.iconphoto(False, img_icon)

# Bild im Ladefenster anzeigen (Bild wird verkleinert)
image = Image.open(icon_path)
image = image.resize((150, 150), Image.ANTIALIAS)  # Bild auf 150x150 Pixel verkleinern
img_icon_small = ImageTk.PhotoImage(image)
img_label = tk.Label(splash_screen, image=img_icon_small)
img_label.pack(pady=10)

# Ladebalken erstellen
progress_var = tk.IntVar()
progress_bar = ttk.Progressbar(splash_screen, orient="horizontal", length=200, mode="determinate", variable=progress_var)
progress_bar.pack(pady=10)

# Prozentanzeige unter dem Ladebalken
progress_label = tk.Label(splash_screen, text="0%")
progress_label.pack()

# Text "Starte..." unter der Prozentanzeige
start_label = tk.Label(splash_screen, text="Starte...")
start_label.pack(pady=10)

# Fenstergröße auf das verkleinerte Bild zuschneiden
splash_screen.geometry("250x350")  # Verkleinertes Ladefenster

# Starte den Ladeprozess
splash_screen.after(100, update_progress)

# Hauptschleife für das Ladefenster starten
splash_screen.mainloop()
